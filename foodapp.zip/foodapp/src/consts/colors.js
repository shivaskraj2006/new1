const COLORS = {
  white: "#FFF",
  dark: "#000",
  primary: "#35D6ED",
  secondary: "#35D6ED",
  light: "#E5E5E5",
  grey: "#908e8c",
  blue: "#3ca6c7",
  lightblue: "#3c3970",
  yellow: "#f59700",
  pink: "#c800f5",
  black: "#171616",
};

export default COLORS;
